// @ts-nocheck
/**
* @type {Map<string, string>} blockIdMap
*/
let blockIdMap = new Map();
(function () {
    let tbody = document.querySelector('table tbody');
    let trs = tbody.querySelectorAll('tr');
    for (let i = 0; i < trs.length; i++) {
        let td = trs[i].querySelectorAll('td');
        blockIdMap.set(td[1].querySelector('a').textContent, 'minecraft:' + td[2].querySelector('code').textContent);
    }
    console.log(blockIdMap);
})();
(function () {
    console.log(JSON.stringify(Object.fromEntries(blockIdMap)));
})();